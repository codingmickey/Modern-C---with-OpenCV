// @file      subtract.cpp
// @author    Ignacio Vizzo     [ivizzo@uni-bonn.de]
//
// Copyright (c) 2019 Ignacio Vizzo, all rights reserved
#include "ipb_arithmetic/subtract.hpp"

float MySubtract(float x, float y) { return x - y; }
